#!/bin/bash
java -jar ahorcado.jar 
